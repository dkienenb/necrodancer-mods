local Player = require "necro.game.character.Player"
local Ability = require "necro.game.system.Ability"
local Action = require "necro.game.system.Action"
local Beatmap = require "necro.audio.Beatmap"
local enum = require "system.utils.Enum"
local components = require "necro.game.data.Components"
local CurrentLevel = require "necro.game.level.CurrentLevel"
local CustomActions = require "necro.game.data.CustomActions"
local GameState = require "necro.client.GameState"
local GrooveChain = require "necro.game.character.GrooveChain"
local event = require "necro.event.Event"
local Chat = require "necro.client.Chat"
local LocalCoop = require "necro.client.LocalCoop"
local Menu = require "necro.menu.Menu"
local settings = require "necro.config.Settings"
local SettingsStorage = require "necro.config.SettingsStorage"
local snapshot = require "necro.game.system.Snapshot"
local Spectator = require "necro.game.character.Spectator"
local PlayerList = require "necro.client.PlayerList"
local Rhythm = require "necro.game.character.Rhythm"
local StatusEffect = require "necro.game.system.StatusEffect"
local utils = require "system.utils.Utilities"

local popupAppeared = false
local patchNotesVersion = "1.5.0"

settingsSeePatchNotes = settings.user.bool {
    name = L"See patch notes",
    id = "seePatchNotes",
    description = L"Enable or disable a patch note popup menu whenever a significant update to the mod is downloaded.\nThis menu will outline any important new features",
    default = true,
}

settingsLastSeenPatchNotes = settings.user.string {
    id = "lastSeenPatchNotes",
    default = "",
    visibility = settings.Visibility.RESTRICTED
}

local function newerPatch(newPatch, oldPatch)
    local oldTokens = oldPatch:gmatch("([^"..".".."]+)")
    local oldVersion = {}
    local newTokens = newPatch:gmatch("([^"..".".."]+)")
    local newVersion = {}
    for t in oldTokens do
        oldVersion[#oldVersion+1] = t
    end
    for t in newTokens do
        newVersion[#newVersion+1] = t
    end
    for i = 1, math.min(#oldVersion, #newVersion) do
        if oldVersion[i] > newVersion[i] then return false
        elseif oldVersion[i] < newVersion[i] then return true end
    end
    return #newVersion > #oldVersion
end

event.tick.add("checkPatch", {order = "menu", sequence = -1}, function (ev)
    if not popupAppeared and settingsSeePatchNotes and newerPatch(patchNotesVersion, settingsLastSeenPatchNotes) and CurrentLevel.isLobby() then
        -- Prompt to switch presets
        Menu.open("GroovyChat_patchNotes")
        settingsLastSeenPatchNotes = patchNotesVersion
        popupAppeared = true
    end
end)

event.menu.add("patchNotes", "GroovyChat_patchNotes", function (ev)
    ev.menu = {
        label = "Groovy Chat " .. patchNotesVersion,
        showIndicatorHUD = true,
        entries = { {
            label = "Patch notes:"
        }, {
            height = 0
        }, {
            label = "- The rewrite, again"
        }, {
            label = "  Keep Moving mode should be more stable, less buggy and more performant"
        }, {
            label = "  The rest too, probably"
        }, {
            height = 0
        }, {
            label = "- Added Pause mode: time stops around you when chatting"
        }, {
            height = 0
        }, {
            label = "  Please report any issues!"
        }, {
            height = 0
        }, {
            label = L"Understood",
            action = function ()
                Menu.closeNamed("GroovyChat_patchNotes")
            end,
            id = "confirm",
          }, {
            label = L"Don't show me patch notes ever again",
            action = function ()
                SettingsStorage.set("mod.GroovyChat.seePatchNotes", false, settings.Layer.LOCAL)
                Menu.closeNamed("GroovyChat_patchNotes")
            end,
            id = "disablePatchNotes",
          },
        },
        escapeAction = function ()
            Menu.closeNamed("GroovyChat_patchNotes")
        end
    }
end)