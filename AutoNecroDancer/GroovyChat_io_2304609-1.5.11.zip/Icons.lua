local Player = require "necro.game.character.Player"
local AnimationTimer = require "necro.render.AnimationTimer"
local Color = require "system.utils.Color"
local event = require "necro.event.Event"
local LocalCoop = require "necro.client.LocalCoop"
local PlayerList = require "necro.client.PlayerList"
local Render = require "necro.render.Render"
local VisualExtent = require "necro.render.level.VisualExtent"
local buffer = Render.getBuffer(Render.Buffer.PLAYER_NAME)
local GC = require "GroovyChat.GroovyChat"

local chatIconParams = {
    animationPeriod = 1.4,
    numFrames = 4,
    texOffsetX = 0,

    texture = "mods/GroovyChat/chat_icon.png",
    offsetX = 0,
    offsetY = -28,
    offsetZ = 32,
    width = 14,
    height = 13,
}
local menuIconParams = {
    animationPeriod = 1,
    numFrames = 1,
    texOffsetX = chatIconParams.numFrames * chatIconParams.width,

    texture = chatIconParams.texture,
    offsetX = chatIconParams.offsetX,
    offsetY = chatIconParams.offsetY,
    offsetZ = chatIconParams.offsetZ,
    width = chatIconParams.width,
    height = chatIconParams.height,
}


local getZOrder, getOrigin = VisualExtent.getZOrder, VisualExtent.getOrigin

local function drawIcon(entity, time, params)
    local args = { rect = {}, texRect = {} }
    local frameX = math.floor(time / params.animationPeriod % 1 * params.numFrames)
    local x, y, z = getOrigin(entity)
    args.rect[1] = x + params.offsetX - params.width * 0.5
    args.rect[2] = y + z + params.offsetY - params.height
    args.rect[3] = params.width
    args.rect[4] = params.height
    args.texRect[1] = params.width * frameX + params.texOffsetX
    args.texRect[2] = 0
    args.texRect[3] = params.width
    args.texRect[4] = args.rect[4]
    args.texture = params.texture
    local zOrder = getZOrder(entity)
    args.z = zOrder + params.offsetZ
    buffer.draw(args)
end


local getAllIcons, getIcons = GC.getAllIcons, GC.getIcons
local isLocallyChatting, isLocallyMenuing = GC.locallyChatting, GC.locallyMenuing
local getAnimationTime = AnimationTimer.getTime
local getPlayerEntities = Player.getPlayerEntities
local isCoopPlayer, getParentPlayerID, isLocal = LocalCoop.isCoopPlayer, LocalCoop.getParentPlayerID, LocalCoop.isLocal
local getAttribute = PlayerList.getAttribute

event.render.add("renderChatIcon", {order = "objects", sequence = 9}, function (ev)
    if getAllIcons() or not getIcons() then return end

    local time = getAnimationTime()
    for _, playerEntity in ipairs(getPlayerEntities()) do
        local playerID = playerEntity.controllable.playerID
        if isCoopPlayer(playerID) then
            playerID = getParentPlayerID(playerID)
        end
        if getAttribute(playerID, GC.hideChatIcons) then goto continue end

        local chatting = getAttribute(playerID, GC.playerChatState)
        local menuing = getAttribute(playerID, GC.playerMenuState)
        if playerEntity.gameObject.tangible and (chatting or menuing) then
            if chatting then
                drawIcon(playerEntity, time, chatIconParams)
            elseif menuing then
                drawIcon(playerEntity, time, menuIconParams)
            end
        end
        ::continue::
    end
end)


local function centerWithinRect(outerRect, width, height)
	return {
		outerRect[1] + (outerRect[3] - width) * 0.5,
		outerRect[2] + (outerRect[4] - height) * 0.5,
		width,
		height
	}
end

local headWidth = 20
local colorOpacity = Color.opacity
event.renderPlayerListEntry.add("renderChatIcon", {order = "ping", sequence = 1}, function (ev)
    if GC.getAllIcons() or not GC.getIcons() or ev.noText then return end

    if ev.entity then
        local playerID = ev.entity.controllable.playerID
        if isCoopPlayer(playerID) then
            playerID = getParentPlayerID(playerID)
        end
        if getAttribute(playerID, GC.hideChatIcons) then return end

        local chatting = getAttribute(playerID, GC.playerChatState) or (isLocal(playerID) and isLocallyChatting(playerID))
        local menuing = getAttribute(playerID, GC.playerMenuState) or (isLocal(playerID) and isLocallyMenuing(playerID))
        local iconParams
        if chatting then
            iconParams = chatIconParams
        elseif menuing then
            iconParams = menuIconParams
        end

        if iconParams then
            local width, height = iconParams.width, iconParams.height
            local drawArgs = {
                texture = iconParams.texture,
                rect = centerWithinRect({
                    ev.textRect.width + ev.textRect.x + (ev.spriteOffsetX or 0) + 4 * ev.scale,
                    ev.textRect.y + ((ev.spriteOffsetY or 0) - 2) * ev.scale,
                    headWidth * ev.scale,
                    ev.textRect.height
                }, width * ev.scale, height * ev.scale),
                color = colorOpacity(ev.opacity),
                texRect = {
                    (iconParams.numFrames - 1) * iconParams.width + iconParams.texOffsetX,
                    0,
                    iconParams.width,
                    iconParams.height
                },
            }

            ev.buffer.draw(drawArgs)

            ev.textRect.x = ev.textRect.x + headWidth * ev.scale
        end
    end
end)