local AffectorItem = require "necro.game.item.AffectorItem"
local Ability = require "necro.game.system.Ability"
local Action = require "necro.game.system.Action"
local AnimationTimer = require "necro.render.AnimationTimer"
local Color = require "system.utils.Color"
local settings = require "necro.config.Settings"
local enum = require "system.utils.Enum"
local ExtraMode = require "necro.game.data.modifier.ExtraMode"
local FastForward = require "necro.client.FastForward"
local components = require "necro.game.data.Components"
local CurrentLevel = require "necro.game.level.CurrentLevel"
local CustomActions = require "necro.game.data.CustomActions"
local GameState = require "necro.client.GameState"
local GrooveChain = require "necro.game.character.GrooveChain"
local event = require "necro.event.Event"
local Chat = require "necro.client.Chat"
local LocalCoop = require "necro.client.LocalCoop"
local Menu = require "necro.menu.Menu"
local Netplay = require "necro.network.Netplay"
local ServerPlayerList = require "necro.server.ServerPlayerList"
local snapshot = require "necro.game.system.Snapshot"
local Spectator = require "necro.game.character.Spectator"
local Player = require "necro.game.character.Player"
local PlayerList = require "necro.client.PlayerList"
local Rhythm = require "necro.game.character.Rhythm"
local GC = {}

-- Client variables
lastInputedDirection = {}
graceBeats = {}

components.register {
    characterStandInsteadOfMove = {},
    characterMoveInSquare = {},
}

local function initPlayerTable(value)
    local table = {}
    for _, playerID in ipairs(PlayerList.getPlayerList()) do
        table[playerID] = value
    end
    return table
end

chatGrace = snapshot.levelVariable({
    gracePermanent = initPlayerTable(false),
    graceBeats = initPlayerTable(0),
    lastInputedDirection = initPlayerTable(0),
})
playerPutIntoSpectator = {}

GC.hideChatIcons = Netplay.PlayerAttribute.extend("HIDE_ICONS", enum.data{user = true})

local grooveModes = enum.sequence {
    MOVE = enum.entry(0, {
        name = L"Keep moving",
        desc = L"Your character will move back and forth when chat is open. Better against hot coals and surprise enemies"
    }),
    STAND = enum.entry(1, {
        name = L"Miss immunity",
        desc = L"When chat is opened, you will not lose your groove chain from standing still or failing actions"
    }),
    SPECTATE = enum.entry(2, {
        name = L"Auto-spectate",
        desc = L"When chat is opened, spectate\nUnspectate when it is closed again"
    }),
    PAUSE = enum.entry(3, {
        name = L"Freeze",
        desc = L"While chat is opened, you and enemies targeting you will not act"
    }),
    NONE = enum.entry(4, {
        name = L"None",
        desc = L"No grace at all. Vanilla behaviour but with chat icons"
    })
}
settingGrooveHow = settings.shared.enum {
    name = L"Groove mode",
    default = grooveModes.MOVE,
    order = 0,
    enum = grooveModes,
}
function GC.getGrooveHow()
    return settingGrooveHow
end
settingGrooveGraceLength = settings.shared.number {
    name = L"Grace period length",
    default = 3,
    order = 1,
    desc = L"How many beats after closing chat it takes for the Groovy Chatting effects to go away.",
    minimum = 0,
}
function GC.getGrooveGraceLength()
    return settingGrooveGraceLength
end
settingIcons = settings.shared.bool {
    name = L"Chat and Menu icons",
    description = L"Show everyone when people are chatting or in menus.",
    default = true,
    order = 2,
}
function GC.getIcons()
    return settingIcons
end
yourIcons = settings.user.bool {
    name = L"Hide your icons",
    default = false,
    description = L"Turn this on if you don't want to show everyone when you are chatting or in menu.",
    order = 9,
    setter = function (value)
        PlayerList.setAttribute(GC.hideChatIcons, value)
    end
}
function GC.getYourIcons()
    return yourIcons
end
allIcons = settings.user.bool {
    name = L"Hide all icons",
    default = false,
    order = 10
}
function GC.getAllIcons()
    return allIcons
end


GC.playerMenuState = Netplay.PlayerAttribute.extend("MENU_STATE", enum.data{user = true})
GC.playerChatState = Netplay.PlayerAttribute.extend("CHAT_STATE", enum.data{user = true})

-- Indexed by local player IDs
local lastSentStates = {chat = {}, menu = {}}

local function shouldMove(entity)
    local playerID = entity.controllable.playerID
    return settingGrooveHow == grooveModes.MOVE and not entity.GroovyChat_characterStandInsteadOfMove and (chatGrace.lastInputedDirection[playerID] ~= 0 or entity.grooveChainInflictDamageOnDrop and entity.grooveChainInflictDamageOnDrop.active)
end
local function shouldStand(entity)
    return settingGrooveHow == grooveModes.STAND or settingGrooveHow == grooveModes.MOVE and entity.GroovyChat_characterStandInsteadOfMove
end
local function shouldSpectate(entity)
    return settingGrooveHow == grooveModes.SPECTATE
end
local function shouldPause(entity)
    return settingGrooveHow == grooveModes.PAUSE
end

local function getGrooveLength(entity)
    local graceTime
    if entity.rhythmSubdivision then
        graceTime = settingGrooveGraceLength * entity.rhythmSubdivision.factor
    else
        graceTime = settingGrooveGraceLength
    end
    return graceTime or 3
end

function setGroovyState(playerID, args)
    local pEntity = Player.getPlayerEntity(playerID)
    if not pEntity then return end

    local chatState, menuState, grace = args.chatState, args.menuState, args.grace
    local state = chatState or menuState

    local forceGrace = false

    if shouldSpectate(pEntity) then
        -- Spectate
        if state and not Spectator.isSpectating(playerID) then
            Spectator.setSpectating(playerID, true)
            playerPutIntoSpectator[playerID] = true
        end
         -- Unspectate
        if not state and Spectator.isSpectating(playerID) and playerPutIntoSpectator[playerID] then
            Spectator.setSpectating(playerID, false)
            forceGrace = true
            playerPutIntoSpectator[playerID] = false
        end
    end

    -- If you turned off chat, gives a grace period
    if not state then
        if (grace and pEntity.gameObject.tangible) or forceGrace then
            local graceTime = getGrooveLength(pEntity)
            chatGrace.graceBeats[playerID] = graceTime
        end
        chatGrace.gracePermanent[playerID] = false
    else
        chatGrace.gracePermanent[playerID] = true
    end

    -- Update for autoplay
    Rhythm.update(playerID)
end

groovyStateActionID, groovyState = CustomActions.registerSystemAction {
    id = "groovyState",
    callback = function (playerID, args)
        setGroovyState(playerID, args)
    end,
}

local function stopGrooving(playerID)
    chatGrace.graceBeats[playerID] = 0
end

local function initializeEmptyTables(playerID)
    if not chatGrace.graceBeats[playerID] then chatGrace.graceBeats[playerID] = 0 end
    if not chatGrace.gracePermanent[playerID] then chatGrace.gracePermanent[playerID] = false end
    if not chatGrace.lastInputedDirection[playerID] then chatGrace.lastInputedDirection[playerID] = 0 end
end

local function locallyInState(playerID)
    return lastSentStates.chat[playerID] or lastSentStates.menu[playerID]
end
local function isGrooving(entity)
    local playerID = entity.controllable.playerID
    return playerID and (chatGrace.graceBeats[playerID] and chatGrace.graceBeats[playerID] > 0 or chatGrace.gracePermanent[playerID])
end

function GC.locallyChatting(playerID) return lastSentStates.chat[playerID] end
function GC.locallyMenuing(playerID) return lastSentStates.menu[playerID] end

local function isSliding(entity)
    return entity.slide and entity.slide.direction ~= Action.Direction.NONE
end

local function getNextDirection(entity)
    local prevPosition = entity.previousPosition
    local position = entity.position
    local playerID = entity.controllable and entity.controllable.playerID
    local lastInputedDirection = chatGrace.lastInputedDirection[playerID] or lastInputedDirection[playerID] or 0

    local rotation = (AffectorItem.entityHasItem(entity, "itemNoReturn") or entity.GroovyChat_characterMoveInSquare) and Action.Rotation.CCW_90 or Action.Rotation.MIRROR
    local oppositePreviousInput = Action.isDirection(lastInputedDirection) and Action.rotateDirection(lastInputedDirection, rotation)
    local directionToPrevious = prevPosition and Action.move(prevPosition.x - position.x, prevPosition.y - position.y) or 1
    if entity.actionFilter and entity.actionFilter.ignoreActions[directionToPrevious] then
        directionToPrevious = 1
    end
    local newDirection = oppositePreviousInput or directionToPrevious
    return newDirection
end

event.objectUpdateRhythm.add("autoPlayLocal", "autoPlay", function (ev)
    if not ev.deterministic then
        if (shouldMove(ev.entity) or shouldPause(ev.entity)) and locallyInState(ev.playerID) and not ev.ignoreRhythm then
            ev.autoPlay = true
        end
    end
end)

event.objectCheckAbility.add("inputLastDirection", {order = "ignoreRhythm", sequence = 5}, function (ev)
    if ev.client then
        local playerID = ev.entity.controllable.playerID
        if not shouldMove(ev.entity) or playerID == 0 or not graceBeats[playerID] or graceBeats[playerID] == 0 or isSliding(ev.entity) then return end

        if ev.action == 0 then
            ev.action = getNextDirection(ev.entity)
            graceBeats[playerID] = graceBeats[playerID] - 1
        elseif Ability.Flag.check(ev.action, Ability.Flag.BEATMAP) then
            graceBeats[playerID] = 0
            lastInputedDirection[playerID] = ev.action
        end
    end
end)

event.objectCheckAbility.add("stopPause", {order = "ignoreRhythm", sequence = 5}, function (ev)
    if ev.client then
        local playerID = ev.entity.controllable.playerID
        if not shouldPause(ev.entity) or playerID == 0 or not graceBeats[playerID] or graceBeats[playerID] == 0 or isSliding(ev.entity) then return end

        if ev.action == 0 then
            graceBeats[playerID] = graceBeats[playerID] - 1
        elseif Ability.Flag.check(ev.action, Ability.Flag.BEATMAP) then
            graceBeats[playerID] = 0
        end
    end
end)

event.tick.add("syncChatState", {order = "chatOpen", sequence = 1}, function (ev)
    if GameState.isPlaying() and not FastForward.isActive() then
        for _, playerID in ipairs(LocalCoop.getLocalPlayerIDs()) do
            local currentChatState = Chat.isChatboxOpen() or false
            local currentMenuState = Menu.isOpen() or false
            if lastSentStates.chat[playerID] ~= currentChatState or lastSentStates.menu[playerID] ~= currentMenuState then
                lastSentStates.chat[playerID] = currentChatState
                lastSentStates.menu[playerID] = currentMenuState

                PlayerList.setAttribute(GC.playerChatState, currentChatState)
                PlayerList.setAttribute(GC.playerMenuState, currentMenuState)

                local pEntity = Player.getPlayerEntity(playerID)
                if not pEntity then return end
                if shouldMove(pEntity) or shouldPause(pEntity) then
                    if currentMenuState or currentChatState then
                        graceBeats[playerID] = -1
                    else
                        graceBeats[playerID] = getGrooveLength(pEntity)
                    end
                elseif (shouldSpectate(pEntity) or shouldStand(pEntity)) and not FastForward.isActive() then
                    groovyState(playerID, {grace = true, chatState = currentChatState, menuState = currentMenuState})
                end
                Rhythm.update(playerID)
            end
        end
    end
end)

event.objectUpdateRhythm.add("autoPlayOpenChat", {order = "autoPlay", sequence = 1}, function(ev)
    -- Players only
    if not Player.isPlayerEntity(ev.entity) then return end
    -- Don't do anything when there's no beats
    if ev.ignoreRhythm then return end

    if not shouldSpectate(ev.entity) and not shouldStand(ev.entity) then return end

    if chatGrace.gracePermanent[ev.entity.controllable.playerID] and not (ev.entity.grooveChainImmunity and ev.entity.grooveChainImmunity.idle == true) then
        ev.autoPlay = true
    end
end)

event.objectGrooveChain.add("chattingIgnoreMisses", {order = "immunity"}, function (ev)
    -- Players only
    if not Player.isPlayerEntity(ev.entity) then return end

    if (shouldStand(ev.entity) and ev.type == GrooveChain.Type.IDLE or shouldSpectate(ev.entity) and ev.type <= GrooveChain.Type.ACTION) and isGrooving(ev.entity) then
        ev.suppressed = true
    end
end)

event.turn.add("graceTickDown", "statusEffects", function (ev)
    for _, pEntity in ipairs(Player.getPlayerEntities()) do
        local playerID = pEntity.controllable.playerID
        initializeEmptyTables(playerID)
        if chatGrace.graceBeats[playerID] > 0 and pEntity.gameObject.active then
            chatGrace.graceBeats[playerID] = chatGrace.graceBeats[playerID] - 1
        end
    end
end)

event.gameStateLevel.add("recalculateGrace", {order = "actionBuffer", sequence = 1}, function (ev)
    for _, pEntity in ipairs(Player.getPlayerEntities()) do
        local playerID = pEntity.controllable.playerID
        if not shouldMove(pEntity) then
            local currentChatState = PlayerList.getAttribute(playerID, GC.playerChatState)
            local currentMenuState = PlayerList.getAttribute(playerID, GC.playerMenuState)
            
            setGroovyState(playerID, {chatState = currentChatState, menuState = currentMenuState})
        end
    end
    for _, playerID in ipairs(LocalCoop.getLocalPlayerIDs()) do
        lastInputedDirection[playerID] = 0
        graceBeats[playerID] = 0
    end
end)

-- Stop any chatting immunity when the person starts moving
event.objectCheckAbility.add("stopGrooving", {order = "ignoreRhythm", sequence = 3}, function(ev)
    -- Players only
    if not Player.isPlayerEntity(ev.entity) then return end

    -- Moves ending it is handled differently
    if shouldMove(ev.entity) or shouldPause(ev.entity) then return end

    if not ev.client and ev.action ~= 0 and chatGrace.graceBeats[ev.playerID] and chatGrace.graceBeats[ev.playerID] > 0 and Ability.Flag.check(Ability.getActionFlags(ev.action), Ability.Flag.BEATMAP) then
        stopGrooving(ev.playerID)
    end
end)

-- Record the last movement direction of an entity, in case it's ever interupted for a beat
event.objectDirection.add("updateLastInputedDirection", {order = "storeAction", sequence = 1}, function (ev)
    -- Players only
    if not Player.isPlayerEntity(ev.entity) then return end

    if not isSliding(ev.entity) then
        local playerID = ev.entity.controllable.playerID
        chatGrace.lastInputedDirection[playerID] = ev.direction
    end
end)

event.objectSpecialAction.add("clearLastInputedDirection", {order = "storeAction", sequence = 1}, function (ev)
    -- Players only
    if not Player.isPlayerEntity(ev.entity) then return end

    if ev.action == 0 then
        if not isSliding(ev.entity) then
            local playerID = ev.entity.controllable.playerID
            chatGrace.lastInputedDirection[playerID] = 0
        end
    end
end)

-- Makes it so the fields are cleared properly when intangibility is forcefully exited somehow
event.objectUnspectate.add("clearValues", {order = "ascent", sequence = -1, filter = {"controllable", "descent"}}, function (ev)
    -- Players only
    if not Player.isPlayerEntity(ev.entity) then return end
    local playerID = ev.entity.controllable.playerID

    if LocalCoop.isLocal(playerID) and ev.entity.descent.active then
        lastInputedDirection[playerID] = 0
        graceBeats[playerID] = 0
    end
end)

event.clientAddInput.add("suppressIdle", {order = "turnID", sequence = 1}, function (ev)
    if ev.action == 0 and settingGrooveHow == grooveModes.PAUSE and (locallyInState(ev.playerID) or (graceBeats[ev.playerID] and graceBeats[ev.playerID] > 0)) then
        ev.suppressed = true
    end
end)

-- -- Makes it so the fields are cleared properly when intangibility is forcefully exited somehow
-- event.objectDescentEnd.add("clearDuration", {order = "intangible", filter = "controllable"}, function (ev)
--     -- Players only
--     if not Player.isPlayerEntity(ev.entity) then return end
--     local playerID = ev.entity.controllable.playerID

--     if PlayerList.getLocalPlayerID() == playerID then graceBeats = 0 end
-- end)

return GC